import './App.css';
import Menu from './Menu/Menu.tsx';
import Cart from './Cart.tsx';
import Launchpad from './Launchpad.tsx';
import Inventory from './Inventory';
// app for fetch calls implemented from: https://jasonwatmore.com/post/2020/01/27/react-fetch-http-get-request-examples
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';



const App: React.FC = () => {
  return (
    <Router>
      <Routes>
      <Route path="/" element={<Launchpad />} />
        <Route path="/menu" element={<Menu />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/inventory" element={<Inventory />} />
      </Routes>
    </Router>
  );
};

export default App;

