import React from 'react';
import { useNavigate } from 'react-router-dom';

class Menu extends React.Component<any, any> {
  constructor(props) {
    super(props);

    this.state = {
      fullmenu: null,
      cart: {},
    };
    this.populate = this.populate.bind(this);
    this.incrCount = this.incrCount.bind(this);
  }

  componentDidMount() {
    this.populate();
  }

  isEmpty(ob) {
    for (var i in ob) {
      return false;
    }
    return true;
  }

  incrCount(id) {
    const cartCopy = JSON.parse(JSON.stringify(this.state.cart));
    cartCopy[id].count = cartCopy[id].count + 1;
    this.setState({
      cart: cartCopy,
    });
  }

  showOrders() {
    if (this.isEmpty(this.state.cart)) {
      return <p>hello</p>;
    } else {
      const data = this.state.cart;
      return (
        <div className="menuCart">
          <ul>
            {Object.keys(data).map((key) => {
              if (data[key].count > 0)
                return (
                  <li key={key}>
                    {data[key].name}: {data[key].count}
                  </li>
                );
              return null;
            })}
          </ul>
        </div>
      );
    }
  }

  populate() {
    fetch('/testmenu.json', { method: 'GET' })
      .then(async (response) => {
        const data = await response.json();
        if (!response.ok) {
          const error = (data && data.message) || response.statusText;
          return Promise.reject(error);
        }

        if (this.isEmpty(this.state.cart)) {
          data.map((menuItem) => {
            const { id, item_name, cost } = menuItem;
            this.state.cart[id] = {
              name: item_name,
              price: cost,
              count: 0,
            };
          });
        }

        this.setState({
          fullmenu: (
            <div className="menu">
              {data.map((menuItem) => {
                const { id, item_name, cost, description } = menuItem;
                return (
                  <article key={id} className="menuItem">
                    <button
                      key={item_name}
                      className="menuButton"
                      onClick={() => this.incrCount(id)}
                    >
                      {item_name}
                    </button>
                    <div className="itemInfo">
                      <header>
                        <h4 className="cost">${cost}</h4>
                      </header>
                      <p className="description">{description}</p>
                    </div>
                  </article>
                );
              })}
            </div>
          ),
        });
      })
      .catch((error) => {
        this.setState({ errorMessage: error.toString() });
        console.error('Error in get count.', error);
      });
  }

  render() {
    return (
      <>
        {this.showOrders()}
        <div className="menu">{this.state?.fullmenu ?? 'Loading'}</div>
        <NavigateButton cart={this.state.cart} />
      </>
    );
  }
}

const NavigateButton = ({ cart }) => {
  const navigate = useNavigate();
  return (
    <button
      onClick={() => navigate('/cart', { state: { cart } })}
      className="navigateButton"
    >
      Go to Cart
    </button>
  );
};

export default Menu;
