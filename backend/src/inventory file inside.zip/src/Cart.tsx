import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom'; 

interface CartItem {
  name: string;
  price: number;
  count: number;
}

interface LocationState {
  cart: { [key: number]: CartItem };
}

const Cart: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { cart } = location.state as LocationState;

  const showOrders = () => {
    const data = cart;
    return (
      <div className="menuCart">
        <ul>
          {Object.keys(data).map((key) => {
            const itemKey = Number(key);
            if (data[itemKey].count > 0)
              return (
                <li key={itemKey}>
                  {data[itemKey].name}: {data[itemKey].count}
                </li>
              );
            return null;
          })}
        </ul>
      </div>
    );
  };

  const handleCheckout = () => {
    
    alert('Proceeding to checkout...');
  };

  const handleNotYet = () => {
    navigate('/menu', {state: {cart} });
  };

  return (
    <>
      {showOrders()}
      <div className="cartActions">
        <button onClick={handleNotYet} className="notYetButton">
          Not Yet
        </button>
        <button onClick={handleCheckout} className="checkoutButton">
          Proceed to Checkout
        </button>
      </div>
    </>
  );
};

export default Cart;
